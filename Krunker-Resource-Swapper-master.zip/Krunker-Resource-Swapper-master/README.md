# How to install
- Download [Zipfile](https://github.com/Tehchy/Krunker-Resource-Swapper/archive/master.zip)
- Extract
- Add your resources
- Open `chrome://extensions/` in chrome
- Drag and drop the this folder into that page

# How to use
- Resource Swapper automatically looks for any files you put in a folder and swaps them
- You MUST follow the folder structure of krunker
- EX: weapons models go in models/weapons/weapon_NUMBER.obj
	- Sniper Rifle = 1
	- Assault Rifle = 2
	- Pistol = 3
	- Submachine Gun = 4
	- Revolver = 5
	- Shotgun = 6
	- Light Machine Gun = 7
	- Semi Auto = 8
	- Rocket Launcher = 9
	- Akimbo Uzi = 10
	- Desert Eagle = 11
	- Alien Blaster = 13
